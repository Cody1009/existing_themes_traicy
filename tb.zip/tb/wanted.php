<h1 id="reqrouteHead">採用情報</h1>
<div style="padding: 10px; background: white; text-indent: 1em; font-size: 16px; line-height: 22px;">
	トラベルメディア「Traicy（トライシー）」を運営する(株)トライシージャパンでは、トラベル関連事業の拡大に伴い、アルバイト及びインターンを募集します。
	<a href="http://www.traicy.com/wanted" class="wanted">応募はこちら</a>
</div>
