 <!--/* 広告 */-->
 <?php if(!is_NoAdsense()): ?>
 <center>
 <!-- 擬似広告に置き換えるために以下の一行を追加 20160619 @sada -->

 <script async defer src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
 <!-- Traicy-20151007 -->
 <ins class="adsbygoogle my_adslot"
 style="display:block"
 data-ad-client="ca-pub-3121993718200907"
 data-ad-slot="6481590338"
 data-ad-region="Traicy-header"
 data-ad-format="auto"></ins>
 <script>
 (adsbygoogle = window.adsbygoogle || []).push({});
</script>
		</center>
		<?php endif; ?>
		<!--/* 広告 */-->

		<span class="clear"></span>

		</div><!-- .title_bar -->
 <script>
 function oritatami(id){
	 obj=(document.all)?document.all(id):((document.getElementById)?document.getElementById(id):null);
	 if(obj) obj.style.display=(obj.style.display=="none")?"block":"none";
 }
</script>


