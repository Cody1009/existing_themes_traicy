<?php
  /**
    記事下のダブルレクタングル下のやつら
  */
 ?>

<div id="bottomArticle">
  <div class="pc_left">
    <div id="wifi">
      <?php get_template_part('wifi-article'); ?>
    </div>
    <div id="skyscanner">
      <?php get_template_part('article-skyscanner'); ?>
    </div>
  </div>
  <div class="pc_right">
    <div id="traicytalk">
      <?php get_template_part('article-traicy-talk'); ?>
    </div>
  </div>
</div>
