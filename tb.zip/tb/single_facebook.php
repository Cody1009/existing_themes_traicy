				<!-- FB　いいねボックス  st -->
				<center class="sp_ad">
					<!-- 850px以上で表示 -->
					<span class="hide_u850">
						<div class="fb-page" data-href="https://www.facebook.com/traicycom?fref=ts" data-width="500" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true" data-show-posts="false"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/traicycom?fref=ts"><a href="https://www.facebook.com/traicycom?fref=ts">トラベルメディア「Traicy」</a></blockquote></div></div>			</span>
					<!-- 850px以上で表示 -->

					<!-- 850px以下で表示 -->
					<span class="hide_o850">
						<div class="fb-page" data-href="https://www.facebook.com/traicycom?fref=ts" data-width="300" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true" data-show-posts="false"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/traicycom?fref=ts"><a href="https://www.facebook.com/traicycom?fref=ts">トラベルメディア「Traicy」</a></blockquote></div></div>			</span>
					<!-- 850px以下で表示 -->
				</center>
				<!-- FB　いいねボックス  en -->
				<!-- ランキング -->
				<span class="hide_o600">
				<?php get_template_part('ranking');?>
				</span>
				<!-- ランキング -->
